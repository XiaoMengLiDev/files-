def longest_run(n):
    ''' (list of numbers) -> (interger)
    Takes a list of umbers and returns the length of the longest run
    '''
    counter = 1
    counters = []
    
    for i in range(len(n)):
        if len(n)==1:
            return 1
        elif i == len(n)-1 and n[i-1] == n[i] and len(counters) != 0 and counter == 1:
            counters.sort()
            return counters[-1]+1
        elif i == len(n)-1 and n[i-1] == n[i] and len(counters) == 0 and counter == 1:
            return counter 
        elif i == len(n)-1 and counter ==1:
            counters.sort()
            return counters[-1]
        elif i == len(n)-1 and counter !=1:
            return counter
        elif float(n[i]) == float(n[i+1]):
            counter = counter + 1
        else:
            counters.append(counter)
            counter = 1
    return 0
input_1 = input("Please input a list of numbers seperated by space: ").strip().split()
print(longest_run(input_1))
    

            
