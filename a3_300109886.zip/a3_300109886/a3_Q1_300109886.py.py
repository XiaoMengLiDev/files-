def number_divisible(input_1,n):
    '''(list of int, int) -> (int)
    Takes a list of interger and interger and return the number of elements in the list that are divisible by n.
    '''
    for p in range (len(input_1)):
        input_1[p]=int(input_1[p])
    
    counter = 0
    for i in range (len(input_1)):
        if input_1[i]%int(n) == 0:
            counter = counter + 1
    return counter

input_1 = input("Please input a list of numbers separated by space: ").strip().split()
n = input("Please input an interger: ")
n = int(n)
result = str(number_divisible(input_1,n))
n = str(n)
print("The number of elements divisible by "+ n[0] + " is " + result)

    
       
