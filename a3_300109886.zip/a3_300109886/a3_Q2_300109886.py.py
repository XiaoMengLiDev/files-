def two_length_run(n):
    '''(list of numbers) -> bool
    Takes a list of numbers as input parameter and returns True if the given list
    has at least one run, and False otherwise
    '''
    for i in range(len(n)):
        if i == len(n)-1:
            return False
        elif n[i] == n[i+1]:
            return True
input_1 = input("Please inputa list of numbers sepearted by space: ").strip().split()
result = two_length_run(input_1)
print(result)
print()
