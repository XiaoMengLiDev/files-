import java.util.Scanner;
/**
* The class <b>TicTacToeGame</b> is the
* class that implements the Tic Tac Toe Game.
* It contains the grid and tracks its progress.
* It automatically maintain the current state of
* the game as players are making moves.
*
* @author Guy-Vincent Jourdan, University of Ottawa
*/

public class TicTacToeGame {

	// FINISH THE VARIABLE DECLARATION
	/**
	* The board of the game, stored as a one dimension array.
	*/
	private CellValue[] board;


	/**
	* level records the number of rounds that have been
	* played so far.
	*/
	private int level;

	/**
	* gameState records the current state of the game.
	*/
	private GameState gameState;


	/**
	* lines is the number of lines in the grid
	*/
	private int lines;

	/**
	* columns is the number of columns in the grid
	*/
	private int columns;


	/**
	* sizeWin is the number of cell of the same type
	* that must be aligned to win the game
	*/
	private int sizeWin;


	/**
	* default constructor, for a game of 3x3, which must
	* align 3 cells
	*/
	public TicTacToeGame(){

		// YOUR CODE HERE
		columns = 3;
		board = new CellValue[9];
		lines = 3;
		sizeWin = 3;
		level=0;
		for(int i = 0; i<board.length;i++){
			board[i]=CellValue.EMPTY;
		}
		gameState = GameState.PLAYING;

	}

	/**
	* constructor allowing to specify the number of lines
	* and the number of columns for the game. 3 cells must
	* be aligned.
	* param lines
	*  the number of lines in the game
	* param columns
	*  the number of columns in the game
	*/
	public TicTacToeGame(int lines, int columns){

		// YOUR CODE HERE
		this.columns = columns;
		this.lines = lines;
		sizeWin = 3;
		level = 0;
		this.board = new CellValue[lines*columns];
		for(int i = 0; i<board.length; i++){
			board[i]=CellValue.EMPTY;
		}
		gameState = GameState.PLAYING;


	}

	/**
	* constructor allowing to specify the number of lines
	* and the number of columns for the game, as well as
	* the number of cells that must be aligned to win.
	* param lines
	*  the number of lines in the game
	* param columns
	*  the number of columns in the game
	* param sizeWin
	*  the number of cells that must be aligned to win.
	*/
	public TicTacToeGame(int lines, int columns, int sizeWin){

		// YOUR CODE HERE
		this.lines = lines;
		this.columns = columns;
		this.sizeWin = sizeWin;
		level = 0;
		board = new CellValue[lines*columns];
		for(int i =0; i<board.length;i++){
			board[i]=CellValue.EMPTY;
		}
		gameState = GameState.PLAYING;

	}



	/**
	* getter for the variable lines
	* return
	* 	the value of lines
	*/
	public int getLines(){

		// YOUR CODE HERE
		return lines;

	}

	/**
	* getter for the variable columns
	* return
	* 	the value of columns
	*/
	public int getColumns(){

		// YOUR CODE HERE
		return columns;

	}

	/**
	* getter for the variable level
	* return
	* 	the value of level
	*/
	public int getLevel(){

		// YOUR CODE HERE
		return level;

	}

	/**
	* getter for the variable sizeWin
	*return
	* 	the value of sizeWin
	*/
	public int getSizeWin(){

		// YOUR CODE HERE
		return sizeWin;

	}

	/**
	* getter for the variable gameState
	* return
	* 	the value of gameState
	*/
	public GameState getGameState(){

		// YOUR CODE HERE

		return gameState;

	}

	/**
	* returns the cellValue that is expected next,
	* in other word, which played (X or O) should
	* play next.
	* This method does not modify the state of the
	* game.
	* return
	*  the value of the enum CellValue corresponding
	* to the next expected value.
	*/
	public CellValue nextCellValue(){

		if(level%2==0){
			return CellValue.X;
		}
		else if(level%2==1){
			return CellValue.O;
		}
		return CellValue.X;

	}

/**
* returns the value  of the cell at
* index i.
* If the index is invalid, an error message is
* printed out. The behaviour is then unspecified
* param i
*  the index of the cell in the array board
* return
*  the value at index i in the variable board.
*/
	public CellValue valueAt(int i) {
		if(i>=0&&i<=(columns*lines)){
			return board[i];
		}

		return board[i];



	}

/**
* This method is called when the next move has been
* decided by the next player. It receives the index
* of the cell to play as parameter.
* If the index is invalid, an error message is
* printed out. The behaviour is then unspecified
* If the chosen cell is not empty, an error message is
* printed out. The behaviour is then unspecified
* If the move is valide, the board is updated, as well
* as the state of the game.
* To faciliate testing, is is acceptable to keep playing
* after a game is already won. If that is the case, the
* a message should be printed out and the move recorded.
* the  winner of the game is the player who won first
* param i
*  the index of the cell in the array board that has been
* selected by the next player
*/
	public void play(int i) {

		// YOUR CODE HERE
		CellValue playerXorO = nextCellValue();
		CellValue whatIsAtI;
		if(i>=0 && i<=(lines*columns)){

			whatIsAtI = valueAt(i);
			if(whatIsAtI==CellValue.EMPTY && playerXorO==CellValue.O){
				board[i]=CellValue.O;
				level++;
			}

			else if(whatIsAtI==CellValue.EMPTY && playerXorO==CellValue.X){
				board[i]=CellValue.X;
				level++;
			}
			else if(whatIsAtI==CellValue.X || whatIsAtI==CellValue.O){
				System.out.println("\n");
				System.out.println("Deepest apologies, this cell has been played\n");
				System.out.println("Please kindly enter a different number\n");

			}

		}

	if(gameState == GameState.PLAYING){
		setGameState(i);
	}

	}

/**
* A helper method which updates the gameState variable
* correctly after the cell at index i was just set in
* the method play(int i)
* The method assumes that prior to setting the cell
* at index i, the gameState variable was correctly set.
* it also assumes that it is only called if the game was
* not already finished when the cell at index i was played
* (i.e. the game was playing). Therefore, it only needs to
* check if playing at index i has concluded the game, and if
* set the oucome correctly
*
* param i
* the index of the cell in the array board that has just
* been set
*/


	private void setGameState(int i){

		// YOUR CODE HERE
		int counter = 0;
		int counter1 = 0;
		int counter2 = 0;
		int counter3 = 0;
		int counter4 = 0;
		int counter5 = 0;
		int counter6 = 0;
		int counter7 = 0;
		int counter8 = 0;
		int counter9 = 0;
		int counter10 = 0;
		int temp = 0;
		int temp2 = 0;
		int j = i;
		int x = j%columns;
		int y = j/ columns;
		int minX = 0;
		int maxX = columns - 1;
		int minY = 0;
		int maxY = lines -1;
		int num;

		for(int k = y; k<= maxY;k++){
			num = x+k*columns;
			if(board[num]==board[j]){
				counter++;
			}else{
				break;
			}
		}
		for(int m = y; minY<=m; m--){
			num = x+m*columns;
			if(board[num]==board[j]){
				counter1++;
			}else{
				break;
			}

		}


		for(int l = x; l <= maxX; l++){
			num = y*columns + x + temp;

			if(board[num] == board[j]){
				counter2 ++;
				temp ++;

			}else{
				break;
			}
		}
		for(int g = x; minY <= g; g--){
			num = y*columns + x + temp2;

			if(board[num] == board[j]){
				counter3 ++;
				temp2 -= 1;
			}else{
				break;
			}
		}


		for(int n = j; n<(columns*lines);n=n+(columns+1)){
			if(board[j]==board[n]){
				if(y!=n/columns){
					counter4++;
				}
			}else{
				break;
			}
		}
		for(int s=j; 0<=s;s=s-(columns+1)){
			if(board[j]==board[s]){
				if(y!=s/columns){
					counter5++;
				}
			}else{
				break;
			}
		}

		for(int t=j; t < lines*columns-1; t=t+(columns-1)){

			if(board[t]==board[j]){

				if(y!=t/columns){

					counter6++;
				}
			}else{
				break;
			}
		}
		for(int r=j; 0 < r; r=r-(columns-1)){
			if(board[r]==board[j]){
				if(y!=r/columns){

					counter7++;
				}
			}else{
				break;
			}
		}


		for(int h = 0; h<board.length; h++){
			if(board[h]==CellValue.EMPTY){
				counter8++;
			}
			else if(board[h]==CellValue.X){
				counter9++;
			}
			else if(board[h]==CellValue.O){
				counter10++;
			}
		}
		if(counter8==0&&(counter9+counter10==board.length)){
			System.out.println("It's a draw");
			gameState = GameState.DRAW;
		}
		if(counter6 + counter7 + 1 >= sizeWin || counter4 + counter5 + 1 >= sizeWin || counter2 + counter3 - 1 >= sizeWin || counter+counter1-1>=sizeWin){
			System.out.println(counter6 + counter7 + 1 >= sizeWin);
			System.out.println("Player "+board[j]+" won");
			if(board[j]==CellValue.X){

				gameState = GameState.XWIN;
			}
			else if(board[j]==CellValue.O){
				gameState = GameState.OWIN;
			}
			else{
				gameState = GameState.PLAYING;
			}
		}


	}



	/**
	* Returns a String representation of the game matching
	* the example provided in the assignment's description
	*
	* return
	*  String representation of the game
	*/


	public String toString(){


		String boardPlane = new String("");
		int spaceI = 0;
		for(int i = 0; i<board.length;i++){
			if((i+1)%columns==0 && (i+1)!=lines*columns){
				if(board[i]!=CellValue.EMPTY){
					boardPlane=boardPlane+' ' +board[i];
				}
				boardPlane = boardPlane+'\n';
				for(int o = 0; o < columns; o++){
					boardPlane+="-----";
				}
				spaceI = 0;
				boardPlane+="\n";


			}else{
				if(board[i]==CellValue.EMPTY){
					boardPlane += "  ";
				}
				if(board[i]!=CellValue.EMPTY){
					boardPlane=boardPlane+' ' + board[i];
					
				}
				if((i+1)!=lines*columns){
					boardPlane+="  | ";

					spaceI++;
				}

			}

		}
		return boardPlane;

	}
	}
