ITI-1121 [C]

Student names: Bill Battushig 	id: 300109257
	       Simon Li	      	id: 300109886

Assignment: The assignment is about making a "Player versus Player" tic tac toe game. The program allows the user to enter the dimensions of the tic tac toe board and also lets the user to decide the winning conditions.
	    This file consists of 6 files including this "README" file and the following files: "CellValue.java", "GameState", "TicTacToe.java", "TicTacToeGame.java",and "StudentInfo.java".
