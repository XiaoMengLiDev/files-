# Course: ITI 1120
# Assignment number 5
# Battushig, Bilegt
# 300109257

import string

def open_file():
    '''None->file object
    Opens, read, and returns the file object
    See the assignment text for what this function should do'''
    # YOUR CODE GOES HERE
    # pass commented pass



    flag = True
    while flag:
        try:
            file_ = input("Enter the name of the file: ").strip()
            f = open(file_).read().lower().split('\n')
            flag = False
        except FileNotFoundError:
            print("The is no file with that name. Try again.")

    
    return f


def read_file(fp):
    '''(file object)->dict
    Reads the contents of the file line by line, process them and store them in a dictionary. It returns the dictionary
    See the assignment text for what this function should do'''
    # YOUR CODE GOES HERE
    # pass
    book = []
    for i in fp:
        book.append(i)
    
    d = {}
    c = []
    m = 0

    for i in range(len(book)):
        c.append(book[i].split(' '))
    for i in range(len(c)):
        for j in range(len(c[i])):
            for k in string.punctuation:
                if k in c[i][j]:
                    c[i][j] = c[i][j].replace(k, '')

    for i in range(len(c)):
        for j in range(len(c[i])):
            if len(c[i][j]) > 1 and c[i][j].isalpha() and c[i][j].isdigit() == False:
                if c[i][j] in d:

                    d[c[i][j]].add(i + 1)
                elif c[i][j] not in d:
                    d[c[i][j]] = {i + 1}

    return d


def find_coexistance(D, query):
    '''(dict,str)->list
    Splits the query into a list of words, and ﬁnd the line numbers for each word. Then converts the resulting set to a sorted list, and
    returns the sorted list.
    See the assignment text for what this function should do'''
    # YOUR CODE GOES HERE
    # pass

    f = []
    common = []
    words = query.split()
    m = []

    for i in words:
        for j in string.punctuation:
            i = i.replace(j, '')
        f.append(i)

    for i in range(len(f)):
        dic = {}
        for j in range(len(D)):
            if f[i] in D:
                dic = D[f[i]]
            else:
                return "Word '"+f[i]+"'not in the file"
        common.append(dic)

    for i in range(len(common) - 1):
        g = 1
        for j in common:

            if g != len(common):
                g += 1
                m.append(j.intersection(common[common.index(j) + 1]))

        common = m
        m = []

    for i in range(len(common)):
        common[i] = list(common[i])

    h = []
    for i in common:
        for j in i:
            h.append(j)
    h.sort()
    return h


##############################
# main
##############################
file = open_file()
d = read_file(file)
flag = True


while flag:

    query = input("Enter one or more words separated by spaces, or 'q' to quit: ").strip().lower()
    if query == 'q':
        flag = False
    else:
        result =find_coexistance(d, query)
        for i in result:
            print(i,end=" ")
        print("\n")
            
# YOUR CODE GOES HERE
