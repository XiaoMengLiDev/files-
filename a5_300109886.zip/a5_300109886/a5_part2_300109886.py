# Course: ITI 1120
# Assignment number 5
# Battushig, Bilegt
# 300109257

class Point:
    'class that represents a point in the plane'

    def __init__(self, xcoord=0, ycoord=0):
        ''' (Point,number, number) -> None
        initialize point coordinates to (xcoord, ycoord)'''
        self.x = xcoord
        self.y = ycoord

    def setx(self, xcoord):
        ''' (Point,number)->None
        Sets x coordinate of point to xcoord'''
        self.x = xcoord

    def sety(self, ycoord):
        ''' (Point,number)->None
        Sets y coordinate of point to ycoord'''
        self.y = ycoord

    def get(self):
        '''(Point)->tuple
        Returns a tuple with x and y coordinates of the point'''
        return (self.x, self.y)

    def move(self, dx, dy):
        '''(Point,number,number)->None
        changes the x and y coordinates by dx and dy'''
        self.x += dx
        self.y += dy

    def __eq__(self, other):
        '''(Point,Point)->bool
        Returns True if self and other have the same coordinates'''
        return self.x == other.x and self.y == other.y
    def __repr__(self):
        '''(Point)->str
        Returns canonical string representation Point(x, y)'''
        return 'Point('+str(self.x)+','+str(self.y)+')'
    def __str__(self):
        '''(Point)->str
        Returns nice string representation Point(x, y).
        In this case we chose the same representation as in __repr__'''
        return 'Point('+str(self.x)+','+str(self.y)+')'

class Rectangle(Point):
    'class that represents a rectangle in 2D space'
    def __init__(self,left,right,color):
        ''' (Rectangle,Point, Point,str) -> None
        initialize left bottom coordinates of the rectangle and the right top coordinates to (left, right)
        initialize the color of the rectangle to (color)'''
        self.color = color
        self.left = left
        self.right = right
        super().__init__()
        
    def get_color(self):
        '''(Rectangle)->str
        Returns a string containing the name of the color of the rectangle'''
        
        return self.color

    def get_bottom_left(self):
        '''(Rectangle)->Point
        Returns a Point containing the coordinates of the left bottom point'''
        
        return self.left

    def get_top_right(self):
        '''(Rectangle)->Point
        Returns a Point containing the coordinates of the right bottom point'''
        
        return self.right

    def reset_color(self,color):
        '''(Rectangle,str)->None
        changes the color of the rectangle by the given color'''
        
        self.color = color

    def move(self,dx,dy):
        '''(Rectangle, number, number)-> None
        Changes the coordinates of the Point by given dx and dy'''

        self.leftv1 = Point.move(self.left,dx,dy)
        self.rightv2=Point.move(self.right,dx,dy)

    def get_perimeter(self):
        '''(Rectangle)->int
        Returns the perimeter of the rectangle'''
        
        self.length = self.right.x -self.left.x
        self.width = self.right.y - self.left.y
        return 2*(self.length + self.width)

    def get_area(self):
        '''(Rectangle)->number
        Returns the area of the rectangle'''
        
        self.length = self.right.x -self.left.x
        self.width = self.right.y - self.left.y
        return self.length*self.width

    def contains(self,dx,dy):
        '''(Rectangle, number, number)->bool
        Returns true if the point exists inside the rectangle or if the point is on the rectangle
        Returns false if the point doesn't exist on the rectangle'''
        
        return dx >= self.left.x and dx<=self.right.x and dy >= self.left.y and dy<=self.right.y

    def intersects(self,other):
        '''(Rectangle, Rectangle)->bool
        Returns true if both rectangles intersects with each other
        Returns false if both rectangles does not intersect with each other'''
        
        if self.left == other.left or self.right == other.right:
            return True
        elif self.left.x <= other.left.x and self.right.x >= other.left.x and self.left.y <= other.left.y and self.right.y >= other.left.y:
        
            return True
        elif other.left.x <= self.right.x and other.left.y <= self.left.y and self.right.x <= other.right.x and self.left.y <= other.right.y:
            
            return True
        elif other.left.x <= self.left.x and other.right.x >= self.left.x and other.left.y <= self.left.y and other.right.y >= self.left.y:
         
            return True
        elif self.left.x <= other.right.x and self.left.y <= other.left.y and other.right.x <= self.right.x and other.left.y <= self.right.y:
          
            return True
        elif self.left.x <= other.left.x and self.right.x >= other.right.x and self.left.y >= other.left.y and self.right.y <= other.right.y:
       
            return True
        elif other.left.x <= self.left.x and other.right.x >= self.right.x and other.left.y >= self.left.y and other.right.y <= self.right.y:
          
            return True
        return False
    
    def __str__(self):
        '''(Rectangle)->str
        Returns a nice representation of the object'''
        
        return 'I am a '+str(self.color)+' rectangle with bottom left corner at '+str(Point.get(self.left))+' and top right corner at '+str(Point.get(self.right))+'.'

    def __repr__(self):
        '''(Rectangle)->str
        Returns canonical representation of the object'''
        
        return 'Rectangle('+str(self.left) +','+str(self.right)+','+"'"+str(self.color)+"')"

class Canvas:
    'class that represents a canvas that contains rectangles in 2D space'
    def __init__(self):
        '''(Canvas)-> None
        initialize the lst to None'''
        
        self.lst = []
    def add_one_rectangle(self,Rectangle):
        '''(Canvas, Rectangle)->None
        Adds Rectangle object to the list'''
        
        self.lst.append(Rectangle)
    def get_the_list(self):
        '''(Canvas)->list
        Returns the list containing the rectangles'''
        
        return self.lst
    def __len__(self):
        '''(Canvas)->int
        Returns the number of rectangles in the list'''
        
        return len(self.lst)
    def count_same_color(self,color):
        '''(Canvas, str)->int
        Returns the number of rectangles that contains the given color'''
        
        counter = 0
        if len(self.lst)!=0:
            for i in self.lst:
                if i.color == color:
                    counter +=1
        return counter
    def total_perimeter(self):
        '''(Canvas)-> int
        Returns the total perimeter of rectangles in the list'''
        
        sum = 0
        if len(self.lst)!=0:
            for i in self.lst:
                sum+=i.get_perimeter()
        return sum
    def __repr__(self):
        '''(Canvas)->str
        Returns canonical representation of the object'''
        
        return 'Canvas('+str(self.lst)+')'
    
    def __str__(self):
        '''(Canvas)->str
        Returns the number of rectangles in the canvas'''
        
        if len(self.lst) > 1:
            return " I have "+str(len(self.lst))+" rectangles"
        elif len(self.lst)==1:
            return " I have a "+str(len(self.lst))+" rectangle"
        else:
            return " I have no rectangle"
    
    def min_enclosing_rectangle(self):
        '''(Canvas)->Rectangle
        Returns the minimum rectangle that encloses all of the rectangles'''
        
        if len(self.lst)!=0:
            minimumx = self.lst[0].left.x
        
            for i in self.lst:
            
                if i.left.x == minimumx:
                    minimumx = i.left.x
                elif i.left.x< minimumx:
                    minimumx = i.left.x

            
            minimumy = self.lst[0].left.y
            for i in self.lst:
                if i.left.y == minimumy:
                    minimumy = i.left.y 
                elif i.left.y  < minimumy:
                    minimumy = i.left.y
                    
            maximumy = self.lst[0].right.y
            
            for i in self.lst:
            
                if i.right.y == maximumy:
                    maximumy = i.right.y
                elif i.right.y > maximumy:
                    maximumy = i.right.y
            

            maximumx = self.lst[0].right.x
            for i in self.lst:
                if i.right.x == maximumx:
                    maximumx = i.right.x
                elif i.right.x > maximumx:
                    maximumx = i.right.x
    
            

        return (Rectangle(Point(minimumx,minimumy),Point(maximumx,maximumy),"blue"))

    def common_point(self):
        '''(Canvas)->bool
        Returns true if all of the rectangles intersect with each other
        Returns false if all of the rectangles does not intersect with each other'''
        
        true = []
        for i in range(len(self.lst)-1):
            for j in range(i+1,len(self.lst)):
                if self.lst[i].intersects(self.lst[j]):
                    true.append(1)
                else:
                    true.append(0)
        for i in true:
            if 1 != i:
                return False
        return True
    
            
                
    
                    
                
    
            
    


    
